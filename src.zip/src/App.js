import React, { useState } from 'react';
import './index.css';

const PokemonApp = () => {
  const [selectedPokemon, setSelectedPokemon] = useState(null);
  const [enemyPokemon, setEnemyPokemon] = useState(null);

  const initialPokemonList = [
    { name: 'Bulbasaur', speciality: 'Bulbasaur can survive for days without eating a single morsel. It stores energy in the bulb on its back.' },
    { name: 'Charmander', speciality: 'Charmander\'s flame on its tail indicates its life force. If the flame goes out, it dies.' },
    { name: 'Squirtle', speciality: 'Squirtle\'s shell is not merely used for protection. The shell\'s rounded shape and the grooves on its surface help minimize resistance in water, enabling this Pokémon to swim at high speeds.' },
    { name: 'Pikachu', speciality: 'Pikachu can generate electric charges, which it uses to discharge electricity to attack enemies or to electrify itself to speed up its movement.' },
    { name: 'Jigglypuff', speciality: 'Jigglypuff\'s vocal cords can freely adjust the wavelength of its voice. This Pokémon uses this ability to sing at precisely the right wavelength to make its foes most drowsy.' },
    { name: 'Meowth', speciality: 'Meowth withdraws its sharp claws into its paws to slinkily sneak about without making any incriminating footsteps. For some reason, this Pokémon loves shiny coins that glitter with light.' },
    { name: 'Psyduck', speciality: 'Psyduck uses a mysterious power. When it does so, this Pokémon generates brain waves that are supposedly only seen in sleepers. This discovery spurred controversy among scholars.' },
    { name: 'Growlithe', speciality: 'Growlithe has a superb sense of smell. Once it smells anything, this Pokémon won\'t forget the scent, no matter what. It uses its advanced olfactory sense to determine the emotions of other living things.' },
    { name: 'Poliwag', speciality: 'Poliwag has a very thin skin. It is possible to see the Pokémon\'s spiral innards right through the skin. Despite its thinness, however, the skin is also very flexible. Even sharp fangs bounce right off it.' },
    { name: 'Abra', speciality: 'Abra sleeps for eighteen hours a day. However, it can sense the presence of foes even while it is sleeping. In such a situation, this Pokémon immediately teleports to safety.' }
  ];

  const selectPokemon = (pokemon) => {
    if (selectedPokemon) {
      const confirmSelection = window.confirm('Do you want to select another Pokémon?');
      if (!confirmSelection) {
        return;
      }
    }
    setSelectedPokemon(pokemon);
    setEnemyPokemon(getRandomPokemon(initialPokemonList.filter(p => p.name !== pokemon.name)));
  };

  const getRandomPokemon = (list) => {
    const randomIndex = Math.floor(Math.random() * list.length);
    return list[randomIndex];
  };

  return (
    <div className="App">
      <h1>Pokémon App</h1>
      <div className="pokemon-container">
        <div className="pokemon-list">
          {initialPokemonList.map((pokemon, index) => (
            <button key={index} onClick={() => selectPokemon(pokemon)}>
              {pokemon.name}
            </button>
          ))}
        </div>
        {selectedPokemon && (
          <div className="pokemon-details">
            <div className="selected-pokemon">
              <img src={`https://img.pokemondb.net/artwork/large/${selectedPokemon.name.toLowerCase()}.jpg`} alt={selectedPokemon.name} />
              <p>{`You have chosen ${selectedPokemon.name}.`}</p>
              <p>{selectedPokemon.speciality}</p>
            </div>
            {enemyPokemon && (
              <div className="enemy-pokemon">
                <img src={`https://img.pokemondb.net/artwork/large/${enemyPokemon.name.toLowerCase()}.jpg`} alt={enemyPokemon.name} />
                <p>{`Your enemy is ${enemyPokemon.name}.`}</p>
                <p>{enemyPokemon.speciality}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PokemonApp;
