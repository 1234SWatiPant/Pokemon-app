import React from 'react';
import ReactDOM from 'react-dom';
import PokemonApp from './App';

ReactDOM.render(<PokemonApp />, document.getElementById('root'));
